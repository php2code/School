Easy PHP Calendar Compatibility Tester

Testing Instructions:
---------------------------------------------------------

1) Unzip and upload all tester files to a single directory named 'tester' on your server.

2) Open the web page http://www.YourDomainName.com/tester/index.php and follow the remaining instructions displayed on the page.

3) Delete the tester directory from the server when finished.

If you need assistance, we are here to help:

Forums: http://www.EasyPHPCalendar.com/forums/

Knowledgebase: http://www.easyphpcalendar.com/support/index.php?_m=knowledgebase&_a=view