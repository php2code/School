<?php
// Easy PHP Calendar
// Copyright 2001-2007 NashTech, Inc.
// http://www.EasyPHPCalendar.com

$licenseTsid="";
$licenseSite="";
$orderNumber="";
$license="";
?>