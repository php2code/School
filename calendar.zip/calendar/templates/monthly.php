<!--head-->
<style type="text/css">
<!--
.tableListings {
	width: 680px;
	border: 1px solid #006699;
	margin: 0px;
	padding: 0px;
}
.tableDate {
	font-family: Geneva, Arial, Helvetica, sans-serif;
	font-size: 11px;
	color: #000000;
	width: 180px;
	text-align: left;
	vertical-align: middle;
	font-weight: normal;
	padding: 2px;
}
.tableTitle {
	font-family: Geneva, Arial, Helvetica, sans-serif;
	font-size: 11px;
	color: #004262;
	width: 500px;
	text-align: left;
	vertical-align: middle;
	font-weight: bold;
	padding: 2px;
}
.tableCategory {
	width: 8px;
}
.tableDescr {
	font-family: Geneva, Arial, Helvetica, sans-serif;
	font-size: 11px;
	color: #383838;
	text-align: left;
	vertical-align: middle;
	font-weight: normal;
}
.tableTime {
	font-family: Geneva, Arial, Helvetica, sans-serif;
	font-size: 11px;
	color: #295569;
	font-weight: normal;
}
-->
</style>
<table border="0" class="tableListings">
<!--head-->


<!--body-->
  <tr>
    <td align="left" valign="top" bgcolor="#EBF2FA" class="tableDate">[date]<br><span class="tableTime">[time]</span></td>
    <td align="left" valign="top" bgcolor="#FFFDF2" class="tableCategory s2[category]">&nbsp;</td>
    <td align="left" valign="top" bgcolor="#FFFDF2" class="tableTitle" [mouseover]>[title]<br>
    <span class="tableDescr">[categories][descr]</span></td>
  </tr>
<!--body-->


<!--foot-->
</table>
<!--foot-->


<!--empty-->
  <tr>
    <td bgcolor="#FFFDF2" class="tableTime"><center>There are no events to display for this time period.</center></td>
  </tr>
<!--empty-->