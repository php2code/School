<?php
//session_save_path(""); // FULL SERVER PATH TO SESSION STORAGE DIRECTORY
?>